function dp(){
    alert('hello world');
}

console.log('hello')

function color(){
    document.body.style.backgroundColor="green"
    
}
function A1(){
    document.getElementById('awt').style.backgroundColor="pink";
}
function qwer(){

}

