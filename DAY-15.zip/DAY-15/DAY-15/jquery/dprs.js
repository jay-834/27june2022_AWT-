$(document).ready(function () {
    $("#MyDiv").draggable();

    $("#MyHomeDiv span").draggable({
        containment: "#MyHomeDiv"
    });

    $("#MyHorizontalDiv span").draggable({
        axis: "x"
    });

    $("#MyVerticalDiv span").draggable({
        axis: "y"
    });


    $("#MyFiftyPixelDiv span").draggable({
        distance: 200
    });

    $("#MyThreeSecondsDelayDiv span").draggable({
        delay:3000
    });
    
   });