$(document).ready(function() {
        $(".center").css("textAlign", "center");
        $(".color").css("background-color","#0B0B45");
        $(".jq").css("color","white");
        $(".jr").css("color","orange");
});